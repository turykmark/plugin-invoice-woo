<?php
class PDF_Invoice {

    public static function generate_pdf_invoice($order_id) {
        $order = wc_get_order($order_id);
        $invoice_number = self::assign_invoice_number($order_id);

        // Initialiser TCPDF
        $pdf = new TCPDF();
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetTitle('Facture ' . $invoice_number);
        $pdf->SetMargins(15, 27, 15);
        $pdf->SetHeaderMargin(0);
        $pdf->SetFooterMargin(10);
        $pdf->SetAutoPageBreak(TRUE, 25);
        $pdf->AddPage();

        // Charger le modèle HTML
        ob_start();
        include plugin_dir_path(__FILE__) . '../templates/invoice-template.php';
        $html_content = ob_get_clean();
        
        // Générer le contenu en PDF
        $pdf->writeHTML($html_content, true, false, true, false, '');

        // Sauvegarder le fichier
        $upload_dir = wp_upload_dir();
        $pdf_path = $upload_dir['basedir'] . '/factures/';
        if (!file_exists($pdf_path)) {
            mkdir($pdf_path, 0755, true);
        }
        $file_name = 'facture-' . $order_id . '.pdf';
        $pdf->Output($pdf_path . $file_name, 'F');

        // Ajouter un lien dans la commande
        $pdf_url = $upload_dir['baseurl'] . '/factures/' . $file_name;
        $order->add_order_note('Facture générée : <a href="' . $pdf_url . '">Télécharger la facture</a>');
    }

    // Fonction pour assigner un numéro de facture unique
    private static function assign_invoice_number($order_id) {
        $current_month = date('Ym');
        return $current_month . '-' . str_pad($order_id, 4, '0', STR_PAD_LEFT);
    }

    // Fonction pour supprimer une facture PDF
    public static function delete_pdf_invoice($order_id) {
        $upload_dir = wp_upload_dir();
        $pdf_path = $upload_dir['basedir'] . '/factures/';
        $file_name = 'facture-' . $order_id . '.pdf';
        $file_path = $pdf_path . $file_name;

        if (file_exists($file_path)) {
            unlink($file_path);
            $order = wc_get_order($order_id);
            $order->add_order_note('Facture supprimée.');
        }
    }
}