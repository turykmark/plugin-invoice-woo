<?php
class PDF_Invoice_Admin_Settings {

    // Enregistrer les paramètres du plugin
    public static function register_settings() {
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_company_name');
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_company_owner');
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_company_legal_status');
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_company_address');
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_company_email');
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_company_phone');
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_company_siret');
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_company_tva');
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_logo_url');

        // Ajout du champ pour le pied de page
        register_setting('woocommerce_pdf_invoice_options', 'woocommerce_pdf_invoice_footer_text');
    }

    // Afficher la page des paramètres dans l'admin
    public static function display_admin_options() {
        ?>
        <div class="wrap">
            <h1>WooCommerce PDF Invoice</h1>
            <form method="post" action="options.php">
                <?php settings_fields('woocommerce_pdf_invoice_options'); ?>
                <table class="form-table">

                    <!-- Champ pour le pied de page -->
                    <tr>
                        <th scope="row">Texte du pied de page</th>
                        <td><textarea name="woocommerce_pdf_invoice_footer_text" rows="5" cols="50"><?php echo esc_attr(get_option('woocommerce_pdf_invoice_footer_text')); ?></textarea></td>
                    </tr>

                    <!-- Autres champs existants -->
                    <tr>
                        <th scope="row">Nom de l'entreprise</th>
                        <td><input type="text" name="woocommerce_pdf_invoice_company_name" value="<?php echo esc_attr(get_option('woocommerce_pdf_invoice_company_name')); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Nom du propriétaire</th>
                        <td><input type="text" name="woocommerce_pdf_invoice_company_owner" value="<?php echo esc_attr(get_option('woocommerce_pdf_invoice_company_owner')); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Statut juridique de l'entreprise</th>
                        <td><input type="text" name="woocommerce_pdf_invoice_company_legal_status" value="<?php echo esc_attr(get_option('woocommerce_pdf_invoice_company_legal_status')); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Adresse</th>
                        <td><textarea name="woocommerce_pdf_invoice_company_address" rows="3" cols="50"><?php echo esc_attr(get_option('woocommerce_pdf_invoice_company_address')); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row">Email</th>
                        <td><input type="email" name="woocommerce_pdf_invoice_company_email" value="<?php echo esc_attr(get_option('woocommerce_pdf_invoice_company_email')); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Téléphone</th>
                        <td><input type="text" name="woocommerce_pdf_invoice_company_phone" value="<?php echo esc_attr(get_option('woocommerce_pdf_invoice_company_phone')); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">SIRET</th>
                        <td><input type="text" name="woocommerce_pdf_invoice_company_siret" value="<?php echo esc_attr(get_option('woocommerce_pdf_invoice_company_siret')); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">TVA</th>
                        <td><input type="text" name="woocommerce_pdf_invoice_company_tva" value="<?php echo esc_attr(get_option('woocommerce_pdf_invoice_company_tva')); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Logo de l'entreprise (URL)</th>
                        <td><input type="text" name="woocommerce_pdf_invoice_logo_url" value="<?php echo esc_attr(get_option('woocommerce_pdf_invoice_logo_url')); ?>" /></td>
                    </tr>

                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}