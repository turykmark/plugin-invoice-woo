<?php
/*
Plugin Name: WooCommerce PDF Invoice
Description: Génération de factures PDF conformes à la législation française pour WooCommerce.
Version: 1.1
Author: Votre Nom
Text Domain: woocommerce-pdf-invoice
*/

// Inclure les classes nécessaires
require_once plugin_dir_path(__FILE__) . 'lib/tcpdf/tcpdf.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-admin-settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-pdf-invoice.php';

// Ajouter le menu d'administration
add_action('admin_menu', 'woocommerce_pdf_invoice_menu');
add_action('admin_init', 'woocommerce_pdf_invoice_settings');

// Fonction pour créer la page des réglages du plugin
function woocommerce_pdf_invoice_menu() {
    add_options_page('WooCommerce PDF Invoice', 'WooCommerce PDF Invoice', 'manage_options', 'woocommerce-pdf-invoice', 'woocommerce_pdf_invoice_options');
}

// Fonction pour afficher la page des réglages du plugin
function woocommerce_pdf_invoice_options() {
    PDF_Invoice_Admin_Settings::display_admin_options();
}

// Initialiser les réglages du plugin
function woocommerce_pdf_invoice_settings() {
    PDF_Invoice_Admin_Settings::register_settings();
}

// Ajouter des actions personnalisées dans la page de commande
add_filter('woocommerce_order_actions', 'add_custom_order_actions');
function add_custom_order_actions($actions) {
    $actions['generate_invoice'] = __('Générer la facture PDF', 'woocommerce');
    $actions['delete_invoice'] = __('Supprimer la facture PDF', 'woocommerce');
    return $actions;
}

// Gérer l'action "Générer la facture"
add_action('woocommerce_order_action_generate_invoice', 'process_generate_invoice_order_action');
function process_generate_invoice_order_action($order) {
    PDF_Invoice::generate_pdf_invoice($order->get_id());
}

// Gérer l'action "Supprimer la facture"
add_action('woocommerce_order_action_delete_invoice', 'process_delete_invoice_order_action');
function process_delete_invoice_order_action($order) {
    PDF_Invoice::delete_pdf_invoice($order->get_id());
}