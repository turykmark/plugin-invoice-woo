<?php
class PDF_Invoice {

    public static function generate_pdf_invoice($order_id) {
        $order = wc_get_order($order_id);
        
        // Récupérer les informations de commande
        $order_number = $order->get_order_number();
        $order_date = $order->get_date_created()->date('Y-m-d');
        $invoice_number = self::assign_invoice_number($order_id);

        // Récupérer les informations du client
        $billing_email = $order->get_billing_email();  // Email du client
        $billing_phone = $order->get_billing_phone();  // Téléphone du client

        // Initialiser TCPDF
        $pdf = new TCPDF();
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetTitle('Facture ' . $invoice_number);
        $pdf->SetMargins(15, 27, 15);
        $pdf->SetHeaderMargin(0);
        $pdf->SetFooterMargin(10);
        $pdf->SetAutoPageBreak(TRUE, 25);
        $pdf->AddPage();

        // Charger le modèle HTML et passer les données de commande et de client
        ob_start();
        include plugin_dir_path(__FILE__) . '../templates/invoice-template.php';
        $html_content = ob_get_clean();

        // Remplacer les informations de commande et du client dans le modèle
        $html_content = str_replace('{order_number}', $order_number, $html_content);
        $html_content = str_replace('{order_date}', $order_date, $html_content);
        $html_content = str_replace('{invoice_number}', $invoice_number, $html_content);
        $html_content = str_replace('{billing_email}', $billing_email, $html_content);
        $html_content = str_replace('{billing_phone}', $billing_phone, $html_content);

        // Générer le contenu en PDF
        $pdf->writeHTML($html_content, true, false, true, false, '');

        // Sauvegarder le fichier
        $upload_dir = wp_upload_dir();
        $pdf_path = $upload_dir['basedir'] . '/factures/';
        if (!file_exists($pdf_path)) {
            mkdir($pdf_path, 0755, true);
        }
        $file_name = 'facture-' . $order_id . '.pdf';
        $pdf->Output($pdf_path . $file_name, 'F');

        // Ajouter un lien dans la commande
        $pdf_url = $upload_dir['baseurl'] . '/factures/' . $file_name;
        $order->add_order_note('Facture générée : <a href="' . $pdf_url . '">Télécharger la facture</a>');
    }

    // Générer un numéro de facture unique pour chaque commande
    private static function assign_invoice_number($order_id) {
        $current_month = date('Y-m');
        $last_invoice_number = get_option('woocommerce_last_invoice_number_' . $current_month, 0);
        $increment = $last_invoice_number + 1;
        update_option('woocommerce_last_invoice_number_' . $current_month, $increment);
        $invoice_number = 'F' . $current_month . '-' . str_pad($increment, 4, '0', STR_PAD_LEFT);
        update_post_meta($order_id, '_invoice_number', $invoice_number);
        return $invoice_number;
    }

    // Fonction pour supprimer une facture PDF
    public static function delete_pdf_invoice($order_id) {
        $upload_dir = wp_upload_dir();
        $pdf_path = $upload_dir['basedir'] . '/factures/';
        $file_name = 'facture-' . $order_id . '.pdf';
        if (file_exists($pdf_path . $file_name)) {
            unlink($pdf_path . $file_name);
        }
    }
}
?>