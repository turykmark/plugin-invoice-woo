<?php
/*
Plugin Name: WooCommerce PDF Invoice
Description: Génération de factures PDF conformes à la législation française pour WooCommerce.
Version: 1.1
Author: Votre Nom
Text Domain: woocommerce-pdf-invoice
*/

// Inclure les classes nécessaires
require_once plugin_dir_path(__FILE__) . 'lib/tcpdf/tcpdf.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-admin-settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-pdf-invoice.php';

// Ajouter le menu d'administration
add_action('admin_menu', 'woocommerce_pdf_invoice_menu');
add_action('admin_init', 'woocommerce_pdf_invoice_settings');

// Fonction pour créer la page des réglages du plugin
function woocommerce_pdf_invoice_menu() {
    add_options_page('WooCommerce PDF Invoice', 'WooCommerce PDF Invoice', 'manage_options', 'woocommerce-pdf-invoice', 'woocommerce_pdf_invoice_options');
}

// Fonction pour afficher la page des réglages du plugin
function woocommerce_pdf_invoice_options() {
    PDF_Invoice_Admin_Settings::display_admin_options();
}

// Initialiser les réglages du plugin
function woocommerce_pdf_invoice_settings() {
    PDF_Invoice_Admin_Settings::register_settings();
}

// Ajouter des actions personnalisées dans la page de commande
add_filter('woocommerce_order_actions', 'add_custom_order_actions');
function add_custom_order_actions($actions) {
    $actions['generate_invoice'] = __('Générer la facture PDF', 'woocommerce');
    $actions['delete_invoice'] = __('Supprimer la facture PDF', 'woocommerce');
    return $actions;
}

// Gérer l'action "Générer la facture"
add_action('woocommerce_order_action_generate_invoice', 'process_generate_invoice_order_action');
function process_generate_invoice_order_action($order) {
    PDF_Invoice::generate_pdf_invoice($order->get_id());
}

// Gérer l'action "Supprimer la facture"
add_action('woocommerce_order_action_delete_invoice', 'process_delete_invoice_order_action');
function process_delete_invoice_order_action($order) {
    PDF_Invoice::delete_pdf_invoice($order->get_id());
}
// Ajouter des champs personnalisés sur la page d'édition de commande
add_action('woocommerce_admin_order_data_after_order_details', 'ajouter_champs_personnalises_commande');

function ajouter_champs_personnalises_commande($order) {
    // Récupérer les valeurs actuelles de la commande
    $order_number = $order->get_order_number();  // Récupère le numéro de commande depuis WooCommerce
    $order_date = $order->get_date_created()->date('Y-m-d');  // Récupère la date de commande depuis WooCommerce
    $invoice_number = get_post_meta($order->get_id(), '_invoice_number', true); // Numéro de facture modifiable

    ?>
    <div class="order_data_column">
        <h4><?php _e('Informations supplémentaires', 'woocommerce'); ?></h4>

        <!-- Numéro de commande (pré-rempli mais modifiable) -->
        <p class="form-field form-field-wide">
            <label for="order_number"><?php _e('Numéro de commande', 'woocommerce'); ?></label>
            <input type="text" name="order_number" id="order_number" value="<?php echo esc_attr($order_number); ?>">
        </p>

        <!-- Date de commande (pré-remplie mais modifiable) -->
        <p class="form-field form-field-wide">
            <label for="order_date"><?php _e('Date de commande', 'woocommerce'); ?></label>
            <input type="date" name="order_date" id="order_date" value="<?php echo esc_attr($order_date); ?>">
        </p>

        <!-- Numéro de facture (modifiable) -->
        <p class="form-field form-field-wide">
            <label for="invoice_number"><?php _e('Numéro de facture', 'woocommerce'); ?></label>
            <input type="text" name="invoice_number" id="invoice_number" value="<?php echo esc_attr($invoice_number); ?>">
        </p>
    </div>
    <?php
}

// Sauvegarder les champs personnalisés lors de la mise à jour de la commande
add_action('woocommerce_process_shop_order_meta', 'sauvegarder_champs_personnalises_commande', 10, 2);

function sauvegarder_champs_personnalises_commande($order_id, $post_data) {
    if (isset($_POST['order_date'])) {
        update_post_meta($order_id, '_order_date', sanitize_text_field($_POST['order_date']));
    }

    if (isset($_POST['order_number'])) {
        update_post_meta($order_id, '_order_number', sanitize_text_field($_POST['order_number']));
    }

    if (isset($_POST['invoice_number'])) {
        update_post_meta($order_id, '_invoice_number', sanitize_text_field($_POST['invoice_number']));
    }
}