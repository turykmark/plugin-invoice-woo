<?php
// Récupérer les données de l'entreprise
$company_name = get_option('woocommerce_pdf_invoice_company_name');
$company_owner = get_option('woocommerce_pdf_invoice_company_owner');
$company_address = nl2br(get_option('woocommerce_pdf_invoice_company_address'));
$company_email = get_option('woocommerce_pdf_invoice_company_email');
$company_phone = get_option('woocommerce_pdf_invoice_company_phone');
$company_siret = get_option('woocommerce_pdf_invoice_company_siret');
$company_url = get_option('woocommerce_pdf_invoice_site_url');
$company_tva = get_option('woocommerce_pdf_invoice_company_tva');

// Récupérer l'URL du logo depuis les options et convertir en chemin absolu
$logo_url = get_option('woocommerce_pdf_invoice_logo_url');

// Convertir l'URL en chemin absolu si l'image est locale
if ($logo_url && strpos($logo_url, get_site_url()) !== false) {
    $logo_path = str_replace(get_site_url(), ABSPATH, $logo_url);
} else {
    $logo_path = $logo_url;  // Si l'image est externe, garde l'URL
}

// Récupérer les données de la commande
$billing_address = $order->get_formatted_billing_address();
$shipping_address = $order->get_formatted_shipping_address() ? $order->get_formatted_shipping_address() : $billing_address;
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: DejaVu Sans, sans-serif; }
        h1 { text-align: center; }
        .invoice-header { margin-bottom: 20px; }
        .invoice-details, .customer-details { margin-top: 20px; }
        .customer-details { float: left; width: 45%; }
        .order-details { float: right; width: 45%; text-align: right; }
        table { width: 100%; border-collapse: collapse; margin-top: 30px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        .logo { text-align: center; margin-bottom: 20px; }
        .logo img { max-width: 150px; }
    </style>
</head>
<body>

    <!-- Logo de l'entreprise -->
    <div class="logo">
        <?php if ($logo_path): ?>
            <img src="<?php echo esc_url($logo_path); ?>" alt="Logo de l'entreprise">
        <?php endif; ?>
    </div>

    <h1>Facture : {invoice_number}</h1>
    <p><strong>Numéro de commande :</strong> {order_number}</p>
    <p><strong>Date de commande :</strong> {order_date}</p>

    <div class="invoice-header">
        <p><strong><?php echo $company_name; ?></strong><br>
        <?php echo $company_owner; ?><br>
        <?php echo $company_address; ?><br>
        Email: <?php echo $company_email; ?><br>
        Téléphone: <?php echo $company_phone; ?><br>
        SIRET: <?php echo $company_siret; ?><br>
        TVA: <?php echo $company_tva; ?></br>
        URL Site: <?php echo $company_url; ?></p>
    </div>

    <div class="customer-details">
        <h2>Détails de facturation</h2>
        <p><?php echo $billing_address; ?></p>
        <p><strong>Email du client :</strong> {billing_email}</p>
<p><strong>Téléphone du client :</strong> {billing_phone}</p>
    </div>

    <div class="order-details">
        <h2>Détails de livraison</h2>
        <p><?php echo $shipping_address; ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Produit</th>
                <th>Quantité</th>
                <th>Prix unitaire</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ( $order->get_items() as $item_id => $item ) : ?>
                <tr>
                    <td><?php echo $item->get_name(); ?></td>
                    <td><?php echo $item->get_quantity(); ?></td>
                    <td><?php echo wc_price( $item->get_total() / $item->get_quantity() ); ?></td>
                    <td><?php echo wc_price( $item->get_total() ); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <p>Total HT: <?php echo wc_price($order->get_subtotal()); ?></p>
    <p>Total TVA: <?php echo wc_price($order->get_total_tax()); ?></p>
    <p>Total TTC: <?php echo wc_price($order->get_total()); ?></p>

    <!-- Pied de page personnalisé -->
    <div class="invoice-footer" style="margin-top: 50px; text-align: center;">
        <p><?php echo nl2br(get_option('woocommerce_pdf_invoice_footer_text')); ?></p>
    </div>

</body>
</html>